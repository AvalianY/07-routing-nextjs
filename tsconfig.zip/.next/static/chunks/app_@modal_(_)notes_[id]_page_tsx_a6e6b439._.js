(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_8b062342._.js",
  "static/chunks/_7adf40f2._.js",
  "static/chunks/_2e6e9cc8._.css"
],
    source: "dynamic"
});

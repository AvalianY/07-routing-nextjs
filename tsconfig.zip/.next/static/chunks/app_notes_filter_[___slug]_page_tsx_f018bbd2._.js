(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f735229a._.js",
  "static/chunks/_93186497._.js",
  "static/chunks/_27d2a5a9._.css"
],
    source: "dynamic"
});
